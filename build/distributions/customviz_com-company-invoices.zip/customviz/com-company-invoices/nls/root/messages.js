define({
    "INVOICES_DISPLAY_NAME": "Invoices Plugin",
    "INVOICES_SHORT_DISPLAY_NAME": "Invoices Plugin",
    "INVOICES_CATEGORY":"Invoices Plugin",
    "INVOICES_ROW_LABEL":"Invoices Plugin Row",
    "INVOICES_ITEM_SIZE":"Item Size",
    "TEXT_MESSAGE": "Hello!  This is the {0} visualization and I have {1} rows of data."

});